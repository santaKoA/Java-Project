package com.expensemanager.project.interfaces;

public interface IValidator {
    public String validate(Object object);
}
