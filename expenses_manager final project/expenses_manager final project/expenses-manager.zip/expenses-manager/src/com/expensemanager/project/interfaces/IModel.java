package com.expensemanager.project.interfaces;

public interface IModel {
}
