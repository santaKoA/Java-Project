package com.expensemanager.project.interfaces.Register;

import com.expensemanager.project.dtos.AccountRegisterDTO;

public interface IRegisterViewModel {
    public void registerNewClient(AccountRegisterDTO client);

}
