package com.expensemanager.project.interfaces.Login;

import com.expensemanager.project.dtos.AccountLoginDTO;

public interface ILoginViewModel {
    public void loginUser(AccountLoginDTO client);
}
