package com.expensemanager.project.interfaces.Report;

public interface IReportViewModel {
    void getReport(String fromDateStr, String toDateStr);
}
